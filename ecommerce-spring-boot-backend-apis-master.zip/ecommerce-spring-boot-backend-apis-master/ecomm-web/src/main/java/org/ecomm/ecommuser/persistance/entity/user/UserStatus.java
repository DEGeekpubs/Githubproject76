package org.ecomm.ecommuser.persistance.entity.user;

public enum UserStatus {
  ACTIVE_NOT_VERIFIED,
  ACTIVE_VERIFIED,
  LOCKED,
  SUSPENDED
}
