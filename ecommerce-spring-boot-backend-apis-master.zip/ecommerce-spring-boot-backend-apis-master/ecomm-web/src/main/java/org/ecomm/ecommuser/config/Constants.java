package org.ecomm.ecommuser.config;

public class Constants {

    public static final String UNAUTHORIZED_USER = "User is not authorized";

}
