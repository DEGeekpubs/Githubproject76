package org.ecomm.ecommuser.persistance.entity.user;

public enum UserRole {
    ADMIN,
    USER
}
