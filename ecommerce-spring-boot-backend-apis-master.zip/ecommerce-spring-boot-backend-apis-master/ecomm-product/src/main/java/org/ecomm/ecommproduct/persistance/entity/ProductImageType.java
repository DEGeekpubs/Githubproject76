package org.ecomm.ecommproduct.persistance.entity;

public enum ProductImageType {

    PRODUCT_IMAGES,
    MANUFACTURER_IMAGES

}
