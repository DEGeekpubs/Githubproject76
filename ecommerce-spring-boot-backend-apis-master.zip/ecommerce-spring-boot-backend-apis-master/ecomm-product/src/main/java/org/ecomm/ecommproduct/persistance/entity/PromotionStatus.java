package org.ecomm.ecommproduct.persistance.entity;

public enum PromotionStatus {
    ACTIVE,
    EXPIRED
}
