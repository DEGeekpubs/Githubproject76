package org.ecomm.ecommproduct.rest.services.admin;

import org.springframework.stereotype.Service;

@Service
public interface VariantService {

    Object getFeaturesVariant(int category);
}
