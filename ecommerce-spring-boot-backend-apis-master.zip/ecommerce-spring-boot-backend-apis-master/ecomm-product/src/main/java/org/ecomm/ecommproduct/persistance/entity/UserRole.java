package org.ecomm.ecommproduct.persistance.entity;

public enum UserRole {
    ADMIN,
    USER
}
