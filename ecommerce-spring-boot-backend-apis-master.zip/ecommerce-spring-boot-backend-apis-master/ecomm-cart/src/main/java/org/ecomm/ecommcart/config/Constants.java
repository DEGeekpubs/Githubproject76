package org.ecomm.ecommcart.config;

public class Constants {

    public static final String UNAUTHORIZED_USER = "User is not authorized";

}
