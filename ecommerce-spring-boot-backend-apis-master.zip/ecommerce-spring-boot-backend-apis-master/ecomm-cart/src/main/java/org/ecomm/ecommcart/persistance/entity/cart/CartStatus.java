package org.ecomm.ecommcart.persistance.entity.cart;

public enum CartStatus {
  ACTIVE,
  SUBMITTED,
  ARCHIVED
}
