package org.ecomm.ecommorder.persistance.entity.order;

public enum DeliveryStatus {
  IN_TRANSIT,
  SHIPPED,
  NOT_SHIPPED,
  DELIVERY_FAILED,
  DELIVERED
}
