package org.ecomm.ecommgateway.config;

public class Constants {

    public static final String AUTH_HEADER_MISSING = "Authorization header is missing in request";
    public static final String AUTH_HEADER_INVALID = "Authorization header is invalid";
    public static final String TOKEN_EXPIRED = "Auth Token Expired";

}
