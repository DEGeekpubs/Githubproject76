package org.ecomm.ecommgateway.persistence.entity;

public enum UserStatus {
  ACTIVE_NOT_VERIFIED,
  ACTIVE_VERIFIED,
  LOCKED,
  SUSPENDED
}
